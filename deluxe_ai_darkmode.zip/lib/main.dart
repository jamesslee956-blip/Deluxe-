import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(DeluxeAIApp());
}

class DeluxeAIApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Deluxe AI',
      theme: ThemeData.dark().copyWith(
        primaryColor: Color(0xFF072146),
        scaffoldBackgroundColor: Color(0xFF0B1220),
        colorScheme: ColorScheme.fromSwatch(brightness: Brightness.dark).copyWith(secondary: Color(0xFFB8860B)),
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFF072146),
          foregroundColor: Colors.white,
        ),
        cardColor: Color(0xFF0F1724),
      ),
      home: ChatPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  ChatMessage(this.text, this.isUser);
}

class ChatPage extends StatefulWidget {
  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final TextEditingController _controller = TextEditingController();
  List<ChatMessage> _messages = [];
  String _apiKey = '';
  String _topic = 'pendidikan';
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _loadApiKey();
  }

  Future<void> _loadApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _apiKey = prefs.getString('OPENAI_API_KEY') ?? '';
    });
    if (_apiKey.isEmpty) _askSetApiKey();
  }

  Future<void> _askSetApiKey() async {
    final controller = TextEditingController();
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF0B1220),
        title: Text('Masukkan OpenAI API Key', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          decoration: InputDecoration(hintText: 'sk-...', hintStyle: TextStyle(color: Colors.white54)),
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF072146)),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setString('OPENAI_API_KEY', controller.text.trim());
              setState(() { _apiKey = controller.text.trim(); });
              Navigator.pop(context);
            },
            child: Text('Simpan')
          )
        ],
      ),
    );
  }

  Widget _buildMessage(ChatMessage m) {
    return Align(
      alignment: m.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        padding: EdgeInsets.all(12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: m.isUser ? Color(0xFF1F2937) : Color(0xFF0F1724),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 4, offset: Offset(0,2))],
        ),
        child: Text(m.text, style: TextStyle(fontSize: 15, color: Colors.white70)),
      ),
    );
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _messages.add(ChatMessage(text, true));
      _controller.clear();
      _loading = true;
    });
    try {
      final reply = await _callOpenAI(text, _topic);
      setState(() {
        _messages.add(ChatMessage(reply, false));
      });
    } catch (e) {
      setState(() {
        _messages.add(ChatMessage('Terjadi kesalahan: $e', false));
      });
    } finally {
      setState(() { _loading = false; });
    }
  }

  Future<String> _callOpenAI(String userMessage, String topic) async {
    if (_apiKey.isEmpty) throw 'API key belum diset. Pergi ke pengaturan.';
    final systemPrompt = "Kamu adalah 'Deluxe AI', asisten belajar yang ramah dan informatif. Fokus membantu pelajar di topik pendidikan, sains, teknologi, bisnis, dan saran olahraga. Jawab dalam Bahasa Indonesia, gaya santai tapi jelas.";

    final messages = [
      {'role': 'system', 'content': systemPrompt},
      {'role': 'user', 'content': '[Topik: $topic] $userMessage'}
    ];

    final url = Uri.parse('https://api.openai.com/v1/chat/completions');
    final response = await http.post(url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_apiKey',
      },
      body: jsonEncode({
        'model': 'gpt-4o-mini',
        'messages': messages,
        'max_tokens': 400,
        'temperature': 0.4,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final content = data['choices'][0]['message']['content'];
      return content.toString().trim();
    } else {
      throw 'Status ${response.statusCode}: ${response.body}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(color: Color(0xFFB8860B), shape: BoxShape.circle),
            child: Center(child: Text('D', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))
          ),
          SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Deluxe AI', style: TextStyle(fontSize: 18, color: Colors.white)),
            Text('Asisten Belajar', style: TextStyle(fontSize: 12, color: Colors.white70))
          ])
        ]),
        actions: [
          IconButton(icon: Icon(Icons.settings), onPressed: _askSetApiKey)
        ],
      ),
      body: Column(
        children: [
          Container(
            color: Color(0xFF071324),
            padding: EdgeInsets.symmetric(vertical: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _topicButton('pendidikan', 'Pendidikan'),
                  _topicButton('sains', 'Sains'),
                  _topicButton('teknologi', 'Teknologi'),
                  _topicButton('bisnis', 'Bisnis'),
                  _topicButton('olahraga', 'Olahraga'),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, i) => _buildMessage(_messages[i]),
            ),
          ),
          if (_loading) Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator()),
          SafeArea(child: _buildInput()),
        ],
      ),
    );
  }

  Widget _topicButton(String key, String label) {
    final selected = _topic == key;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() { _topic = key; }),
        selectedColor: Color(0xFF072146),
        backgroundColor: Color(0xFF0F1724),
        labelStyle: TextStyle(color: selected ? Colors.white : Colors.white70),
      ),
    );
  }

  Widget _buildInput() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: Color(0xFF071324),
      child: Row(children: [
        Expanded(child: TextField(
          controller: _controller,
          minLines: 1,
          maxLines: 4,
          style: TextStyle(color: Colors.white),
          decoration: InputDecoration(hintText: 'Tanyakan sesuatu ke Deluxe AI...', hintStyle: TextStyle(color: Colors.white54), border: OutlineInputBorder(borderRadius: BorderRadius.circular(8))),
        )),
        SizedBox(width: 8),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF072146)),
          onPressed: _loading ? null : _sendMessage,
          child: Icon(Icons.send, color: Colors.white),
        )
      ]),
    );
  }
}