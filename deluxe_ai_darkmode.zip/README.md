Deluxe AI - Flutter (GitHub Actions ready) - Dark Mode
=====================================================

Instruksi singkat:
1. File project ini menyertakan logo di `assets/logo.png`. Jika ingin ganti ikon, replace that file with your image (512x512 recommended).
2. Commit & push folder ke GitHub (private repo direkomendasikan).
3. Workflow ada di `.github/workflows/flutter-build.yml` untuk build otomatis.
4. Buka tab Actions di GitHub, jalankan workflow 'Build Deluxe AI APK' atau push ke branch main.
5. Setelah build selesai, download APK dari Artifacts.

Security:
- App requests OpenAI API Key on first run. Do NOT share your key publicly.
- For production, use a secure backend proxy to protect API keys.